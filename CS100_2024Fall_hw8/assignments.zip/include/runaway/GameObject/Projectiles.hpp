#ifndef PROJECTILES_HPP__
#define PROJECTILES_HPP__

#include "runaway/GameObject/GameObject.hpp"

// TODO

#endif // !PROJECTILES_HPP__
