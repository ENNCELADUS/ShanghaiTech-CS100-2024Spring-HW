#ifndef ENEMIES_HPP__

#define ENEMIES_HPP__

#include <memory>

#include "runaway/GameObject/GameObject.hpp"
#include "runaway/GameWorld/GameWorld.hpp"

// TODO

#endif // !ENEMIES_HPP__