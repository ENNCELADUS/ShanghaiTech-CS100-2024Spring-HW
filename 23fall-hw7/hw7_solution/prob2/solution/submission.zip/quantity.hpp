#ifndef QUANTITY_HPP
#define QUANTITY_HPP

#include <cmath>

template <int Mass, int Length, int Time, int ElectricCurrent, int Temperature,
          int LuminousIntensity, int AmountOfSubstance>
struct Dimensions {};

namespace detail {

template <typename T> inline constexpr auto isDimensions = false;

template <int M, int L, int T, int EC, int Tmp, int LI, int AOS>
inline constexpr auto isDimensions<Dimensions<M, L, T, EC, Tmp, LI, AOS>> =
    true;

template <typename, typename> struct DimMultiplies;

template <int M1, int L1, int T1, int EC1, int Tmp1, int LI1, int AOS1, int M2,
          int L2, int T2, int EC2, int Tmp2, int LI2, int AOS2>
struct DimMultiplies<Dimensions<M1, L1, T1, EC1, Tmp1, LI1, AOS1>,
                     Dimensions<M2, L2, T2, EC2, Tmp2, LI2, AOS2>> {
  using result = Dimensions<M1 + M2, L1 + L2, T1 + T2, EC1 + EC2, Tmp1 + Tmp2,
                            LI1 + LI2, AOS1 + AOS2>;
};

template <typename, typename> struct DimDivides;

template <int M1, int L1, int T1, int EC1, int Tmp1, int LI1, int AOS1, int M2,
          int L2, int T2, int EC2, int Tmp2, int LI2, int AOS2>
struct DimDivides<Dimensions<M1, L1, T1, EC1, Tmp1, LI1, AOS1>,
                  Dimensions<M2, L2, T2, EC2, Tmp2, LI2, AOS2>> {
  using result = Dimensions<M1 - M2, L1 - L2, T1 - T2, EC1 - EC2, Tmp1 - Tmp2,
                            LI1 - LI2, AOS1 - AOS2>;
};

template <typename, int> struct DimPower;

template <int M, int L, int T, int EC, int Tmp, int LI, int AOS, int Power>
struct DimPower<Dimensions<M, L, T, EC, Tmp, LI, AOS>, Power> {
  using result = Dimensions<M * Power, L * Power, T * Power, EC * Power,
                            Tmp * Power, LI * Power, AOS * Power>;
};

template <typename> struct DimSqrt;

template <int M, int L, int T, int EC, int Tmp, int LI, int AOS>
struct DimSqrt<Dimensions<M, L, T, EC, Tmp, LI, AOS>> {
  static_assert(M % 2 == 0, "Mass must be a multiple of 2.");
  static_assert(L % 2 == 0, "Length must be a multiple of 2.");
  static_assert(T % 2 == 0, "Time must be a multiple of 2.");
  static_assert(EC % 2 == 0, "ElectricCurrent must be a multiple of 2.");
  static_assert(Tmp % 2 == 0, "Temperature must be a multiple of 2.");
  static_assert(LI % 2 == 0, "LuminousIntensity must be a multiple of 2.");
  static_assert(AOS % 2 == 0, "AmountOfSubstance must be a multiple of 2.");
  using result =
      Dimensions<M / 2, L / 2, T / 2, EC / 2, Tmp / 2, LI / 2, AOS / 2>;
};

} // namespace detail

template <typename T, typename Dim> class Quantity {
  static_assert(detail::isDimensions<Dim>);

  T mValue;

public:
  constexpr explicit Quantity(const T &x) : mValue{x} {}

  constexpr const T &value() const { return mValue; }

  constexpr Quantity &operator+=(const Quantity &rhs) {
    mValue += rhs.value();
    return *this;
  }

  constexpr Quantity &operator-=(const Quantity &rhs) {
    mValue -= rhs.value();
    return *this;
  }

  constexpr Quantity &
  operator*=(const Quantity<T, Dimensions<0, 0, 0, 0, 0, 0, 0>> &scalar) {
    mValue *= scalar.value();
    return *this;
  }

  constexpr Quantity &
  operator/=(const Quantity<T, Dimensions<0, 0, 0, 0, 0, 0, 0>> &scalar) {
    mValue /= scalar.value();
    return *this;
  }

  constexpr Quantity operator+(const Quantity &rhs) const {
    return Quantity(value() + rhs.value());
  }

  constexpr Quantity operator-(const Quantity &rhs) const {
    return Quantity(value() - rhs.value());
  }

  constexpr Quantity operator-() const { return Quantity(-value()); }

  constexpr Quantity operator+() const { return Quantity(value()); }
};

template <typename T, typename D1, typename D2>
constexpr auto operator*(const Quantity<T, D1> &lhs,
                         const Quantity<T, D2> &rhs) {
  return Quantity<T, typename detail::DimMultiplies<D1, D2>::result>(
      lhs.value() * rhs.value());
}

template <typename T, typename D1, typename D2>
constexpr auto operator/(const Quantity<T, D1> &lhs,
                         const Quantity<T, D2> &rhs) {
  return Quantity<T, typename detail::DimDivides<D1, D2>::result>(lhs.value() /
                                                                  rhs.value());
}

template <int Power, typename T, typename D>
constexpr auto pow(const Quantity<T, D> &x) {
  return Quantity<T, typename detail::DimPower<D, Power>::result>(
      std::pow(x.value(), Power));
}

template <typename T, typename D> constexpr auto sqrt(const Quantity<T, D> &x) {
  return Quantity<T, typename detail::DimSqrt<D>::result>(std::sqrt(x.value()));
}

template <typename T>
using Scalar = Quantity<T, Dimensions<0, 0, 0, 0, 0, 0, 0>>;
template <typename T> using Mass = Quantity<T, Dimensions<1, 0, 0, 0, 0, 0, 0>>;
template <typename T>
using Length = Quantity<T, Dimensions<0, 1, 0, 0, 0, 0, 0>>;
template <typename T> using Time = Quantity<T, Dimensions<0, 0, 1, 0, 0, 0, 0>>;
template <typename T>
using ElectricCurrent = Quantity<T, Dimensions<0, 0, 0, 1, 0, 0, 0>>;
template <typename T>
using Temperature = Quantity<T, Dimensions<0, 0, 0, 0, 1, 0, 0>>;
template <typename T>
using LuminousIntensity = Quantity<T, Dimensions<0, 0, 0, 0, 0, 1, 0>>;
template <typename T>
using AmountOfSubstance = Quantity<T, Dimensions<0, 0, 0, 0, 0, 0, 1>>;

#endif // QUANTITY_HPP